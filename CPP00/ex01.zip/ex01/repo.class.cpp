#include "repo.class.hpp"
#include "contact.class.hpp"

repo::repo()
{
	this->id = 0;
}

repo::~repo()
{
}

void	repo::addcontact()
{
	if (this->id >= 8)
		std::cout << "The repository is full !" << std::endl;
	else
	{
		this->contact[this->id].getinfo(this->id + 1);
		this->id++;
	}
}

void	repo::searchcontact(void)
{
	if (this->id == 0)
		std::cout << "This repository is empty !" << std::endl;
	else
	{
		for (int i = 1; i <= this->id; i++)
		{
			std::cout << "Contact " << i << ": " << std::endl;
			this->contact[i].searchcontact(i);
		}
	}
}