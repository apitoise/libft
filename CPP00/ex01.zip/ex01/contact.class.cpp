#include "contact.class.hpp"

std::string			contact::nameinfo[11] = {
	"First Name : ",
	"Last Name : ",
	"Nickname : ",
	"Login : ",
	"Postal Address : ",
	"Email Address : ",
	"Phone Number : ",
	"Birthday : ",
	"Favorite Meal : ",
	"Underwear Color : ",
	"Darkest Secret : ",
};

contact::contact() {

	for (int i = Fname; i <= Secret; i++)
		this->information[i] = std::string();

}

contact::~contact() {

}

void	contact::getinfo(int id)
{
	for (int i = Fname; i <= Secret; i++)
	{
		std::cout << contact::nameinfo[i];
		std::getline(std::cin, this->information[i]);
	};
}

void	contact::searchcontact(int id)
{
		for (int j = Fname; j <= Secret; j++)
			std::cout << j << contact::nameinfo[j] << contact[id]::information[j] << std::endl;
}