#include "repo.class.hpp"

int		main(void)
{
	repo		repo;

	repo.fieldentry();
	return (0);
}